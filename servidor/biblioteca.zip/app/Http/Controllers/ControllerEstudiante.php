<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\estudiante;

class ControllerEstudiante extends Controller
{
   	public function index()
   	{
   		$estudiantes = Estudiante::all();

   		return response()->json([
   			'estudiantes' => $estudiantes
   		]);
   	}

   	public function store(Request $request)
   	{
   		Estudiante::create($request->all());

   		return response()->json([
   			'success' => true,
   			'message' => 'Estudiante registrado correctamente'
   		]);
   	}

   	public function update($id, Request $request)
   	{
   		$estudiante = Estudiante::find($id);

   		$estudiante->update($request->all());

   		return response()->json([
   			'success' => true,
   			'message' => 'Estudiante actualizado correctamente'
   		]);
   	}

   	public function delete($id)
   	{
   		$estudiante = Estudiante::find($id);

         if($estudiante->prestamos->count() > 0)
            return response()->json([
               'success' => false,
               'message' => 'No puede eliminar a este estudiante porque tiene prestamos registrados'
            ]); 

   		$estudiante->delete();

   		return response()->json([
   			'success' => true,
   			'message' => 'Estudiante eliminado correctamente'
   		]);
   	}
}
