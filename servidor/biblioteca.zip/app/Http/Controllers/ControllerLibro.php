<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Libro;

class ControllerLibro extends Controller
{
   	public function index()
   	{
   		$libros = Libro::all();

   		return response()->json([
   			'libros' => $libros
   		]);
   	}

   	public function store(Request $request)
   	{
   		Libro::create($request->all());

   		return response()->json([
   			'success' => true,
   			'message' => 'Libro registrado correctamente'
   		]);
   	}

   	public function update($id, Request $request)
   	{
   		$libro = Libro::find($id);

   		$libro->update($request->all());

   		return response()->json([
   			'success' => true,
   			'message' => 'Libro actualizado correctamente'
   		]);
   	}

   	public function delete($id)
   	{
   		$libro = Libro::find($id);

         if($libro->prestamos->count() > 0)
            return response()->json([
               'success' => false,
               'message' => 'No puede eliminar este libro porque tiene prestamos registrados'
            ]);

   		$libro->delete();

   		return response()->json([
   			'success' => true,
   			'message' => 'Libro eliminado correctamente'
   		]);
   	}
}
