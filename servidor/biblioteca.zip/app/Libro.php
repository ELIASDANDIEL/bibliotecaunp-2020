<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Libro extends Model
{
    protected $table = 'libro';
    protected $fillable = ['titulo','autor','precio','anio'];

    protected $casts = [
    	'precio' => 'float'
    ];

    public function prestamos()
    {
    	return $this->hasMany(Prestamo::class);
    }
}
