app
	.component('libros',{
		templateUrl: './main/views/libros/libros.html',
		controller: function ($scope,$http) 
		{
			var scope = $scope
			var server = '../public/'

			const Clean = () => 
			{
				scope.object = {
					id: null,
					descripcion: null,
					precio: null,
					anio: null,
					autor: null
				}
			}

			const Init = () => 
			{
				$http.get(server + 'libro')
					.then(res => {
						scope.libros = res.data.libros
					})
			}

			scope.save = () => 
			{

				if(scope.object.id)
				{
					$http.put(server + 'libro/update/' + scope.object.id, scope.object)
						.then(res => {
							PostTransaction(res)
						})
				}
				else
				{
					$http.post(server + 'libro/store', scope.object)
						.then(res => {
							PostTransaction(res)	
						})
				}
			}

			scope.delete = (id) => 
			{
				$http.delete(server + 'libro/delete/' + id)
					.then(res => {
						PostTransaction(res)
					})
			}

			scope.clean = () => {
				Clean()
			}

			scope.load = (libro) => {
				scope.object = angular.copy(libro)
			}

			const PostTransaction = (res) => 
			{
				alert(res.data.message)

				if(res.data.success)
				{
					Init()
					Clean()
				}
			}

			Init()
			Clean()

		}
	})